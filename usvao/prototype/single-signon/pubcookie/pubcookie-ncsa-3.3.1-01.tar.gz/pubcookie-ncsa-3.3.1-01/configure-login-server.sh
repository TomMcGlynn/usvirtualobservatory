#! /bin/bash

./configure --enable-login --disable-apache --prefix=/usr/local/nvo/pubcookie/pubcookie-ncsa-3.3.1
