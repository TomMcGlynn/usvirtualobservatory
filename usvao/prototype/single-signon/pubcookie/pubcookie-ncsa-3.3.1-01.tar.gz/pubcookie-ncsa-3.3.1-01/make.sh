#! /bin/bash

make top_builddir=/usr/lib/httpd top_srcdir=/usr/lib/httpd $@
