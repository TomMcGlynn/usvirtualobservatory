#! /bin/bash

./configure --prefix=/usr/local/nvo/pubcookie/pubcookie-ncsa-3.3.1
